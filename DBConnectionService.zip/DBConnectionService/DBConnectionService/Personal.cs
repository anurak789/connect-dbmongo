﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DBConnectionService
{
    public class Personal
    {
        [DataMember]
        public ObjectId Id { get; set; }
        //public int Id { get; set; }
        [DataMember]
        public string Fname { get; set; }
        [DataMember]
        public string Lname { get; set; }
        [DataMember]
        public string Address { get; set; }

        public Personal()
        {
                
        }
        //public Personal(ObjectId id, string fname, string lname, string address)
        //{

        //}
        /*
        public Personal()
        {
            //var connectionString = "mongodb://localhost:27017";
            var connectionString = "mongodb://10.42.85.139:27017";
            var client = new MongoClient(connectionString);
            var db = client.GetDatabase("PersonalDetailDB");
            var collection = db.GetCollection<Personal>("people");
            //MongoCollection<Personal> collection1 = db.GetCollection<Personal>("people");
            Personal p1 = new Personal()
            { Id = ObjectId.GenerateNewId(), Fname = "Luke", Lname = "Moriaty", Address = "Gainesville" };
            collection.Save(p1);

        }*/

    }
}
