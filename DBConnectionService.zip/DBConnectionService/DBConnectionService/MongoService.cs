﻿using MongoDB.Driver;
using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver.Builders;


namespace DBConnectionService
{
    [DataContract]
    public class MongoService : IMongoService
    {
        List<Personal> IMongoService.GetPersonal()
        {
            var connectionString = "mongodb://10.42.85.139:27017";
            //var connectionString = "mongodb://localhost:27017";
            MongoClient client = new MongoClient(connectionString);
            MongoServer server = client.GetServer();
            MongoDatabase database = server.GetDatabase("personaldetail");
            MongoCollection collection = database.GetCollection<Personal>("people");

            List<Personal> list = new List<Personal>();
            var persons = database.GetCollection("people").FindAll().AsEnumerable();
            list = (from person in persons
                    select new Personal
                    {
                        Fname = person["Fname"].AsString,
                        Lname = person["Lname"].AsString,
                        Address = person["Address"].AsString
                    }).ToList();
            return list;

        }
        public string GetDBConnection()
        {

            throw new NotImplementedException();
        }

        public void DeletePersonById(ObjectId id)
        {
            var connectionString = "mongodb://10.42.85.139:27017";
            //var connectionString = "mongodb://localhost:27017";
            MongoClient client = new MongoClient(connectionString);
            MongoServer server = client.GetServer();
            MongoDatabase database = server.GetDatabase("personaldetail");
            MongoCollection collection = database.GetCollection<Personal>("people");
            MongoCollection<Personal> records = database.GetCollection<Personal>("people");
            var query = Query.EQ("_id", new BsonObjectId("id"));
            records.Remove(query);
        }
        public void AddPerson()
        {
            var connectionString = "mongodb://10.42.85.139:27017";
            //var connectionString = "mongodb://localhost:27017";
            MongoClient client = new MongoClient(connectionString);
            MongoServer server = client.GetServer();
            MongoDatabase database = server.GetDatabase("personaldetail");
            MongoCollection collection = database.GetCollection<Personal>("people");
          
            var person = new Personal()
            {
                Id = ObjectId.GenerateNewId(),
                Fname = "anurag",
                Lname = "MjMjMj",
                Address= "Theong"                
            };
            collection.Insert(person);
            //throw new NotImplementedException();
        }

        /* Backup
        public void AddPerson()
        {
            var connectionString = "mongodb://10.42.85.139:27017";
            //var connectionString = "mongodb://localhost:27017";
            MongoClient client = new MongoClient(connectionString);
            MongoServer server = client.GetServer();
            MongoDatabase database = server.GetDatabase("personaldetail");
            MongoCollection collection = database.GetCollection<Personal>("people");

            var person = new Personal
            {
                Id = ObjectId.GenerateNewId(),
                Fname = "Aom",
                Lname = "Pkham",
                Address = "North"
            };
            collection.Insert(person);
            var id = person.Id;
        }
        */
    }

}

