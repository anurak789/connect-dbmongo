﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DBConnectionService
{
    [ServiceContract]
    public interface IMongoService
    {
        [OperationContract]
        List<Personal> GetPersonal();
        [OperationContract]
        void AddPerson();
        [OperationContract]
        void DeletePersonById(ObjectId id);
        string GetDBConnection();
    }




}
